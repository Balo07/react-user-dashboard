# API Documentation

Base URL: http://localhost:8000

## POST /production
Body:
{
  "producer": "Detola Ltd.",
  "product_type": "PET Bottles",
  "volume_kg": 1000,
  "zone": "Ikeja",
  "date": "2025-08-01"
}

## POST /collection
Body:
{
  "collector": "Sanmi Recyclers",
  "source": "Market",
  "volume_kg": 150,
  "zone": "Lekki",
  "date": "2025-08-02"
}

## GET /stats
Query: month=YYYY-MM (optional)
Returns totals and recycling_rate.

## GET /recent
Last 20 mixed entries.

## POST /seed
Populate demo data.

## GET /insights
Returns human-readable policy suggestions.
