# Onboarding

1) Start backend (FastAPI) and frontend (Vite).
2) Visit backend docs at /docs.
3) POST /seed to load demo data.
4) Open the dashboard and show stats.
5) Record a 3-4 minute demo with docs/demo_script.md.
