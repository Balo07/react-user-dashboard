# Demo Script (3-4 mins)

Intro: who you are and the problem.
Show /docs, then POST /seed.
Open dashboard, point out Total Produced, Total Collected, Recycling Rate.
Explain AI insights endpoint and recommendations.
Wrap up with policy impact and next steps.
