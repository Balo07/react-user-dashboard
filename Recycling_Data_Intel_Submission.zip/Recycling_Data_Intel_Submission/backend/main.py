from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Literal
from datetime import date
from collections import deque

app = FastAPI(title="Recycling Data Intelligence", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

production_store: deque = deque(maxlen=5000)
collection_store: deque = deque(maxlen=5000)

class ProductionEntry(BaseModel):
    producer: str
    product_type: str = "PET Bottles"
    volume_kg: float
    zone: Optional[str] = None
    date: date

class CollectionEntry(BaseModel):
    collector: str
    source: Literal["Market","Community","Municipal","Environment"] = "Market"
    volume_kg: float
    zone: Optional[str] = None
    date: date

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/production")
def add_production(entry: ProductionEntry):
    production_store.append(entry)
    return {"ok": True, "count": len(production_store)}

@app.post("/collection")
def add_collection(entry: CollectionEntry):
    collection_store.append(entry)
    return {"ok": True, "count": len(collection_store)}

@app.get("/recent")
def recent(limit: int = 20):
    mixed = []
    for e in list(production_store)[-limit:]:
        mixed.append({"kind":"production","entity":e.producer,"zone":e.zone,"volume_kg":e.volume_kg,"date":str(e.date)})
    for e in list(collection_store)[-limit:]:
        mixed.append({"kind":"collection","entity":e.collector,"zone":e.zone,"volume_kg":e.volume_kg,"date":str(e.date)})
    mixed.sort(key=lambda x: x["date"], reverse=True)
    return mixed[:limit]

@app.get("/stats")
def stats(month: Optional[str] = None):
    def in_month(d: date) -> bool:
        if not month: return True
        y, m = month.split("-")
        return d.year == int(y) and d.month == int(m)

    total_p = sum(e.volume_kg for e in production_store if in_month(e.date))
    total_c = sum(e.volume_kg for e in collection_store if in_month(e.date))
    rate = (total_c / total_p) if total_p > 0 else 0.0

    by_zone = {}
    for e in production_store:
        if in_month(e.date):
            z = e.zone or "Unknown"
            by_zone.setdefault(z, {"produced":0.0,"collected":0.0})
            by_zone[z]["produced"] += e.volume_kg
    for e in collection_store:
        if in_month(e.date):
            z = e.zone or "Unknown"
            by_zone.setdefault(z, {"produced":0.0,"collected":0.0})
            by_zone[z]["collected"] += e.volume_kg

    return {
        "total_produced": round(total_p,2),
        "total_collected": round(total_c,2),
        "recycling_rate": round(rate,4),
        "by_zone": [{"zone":z, **vals} for z, vals in by_zone.items()]
    }

@app.post("/seed")
def seed():
    from datetime import date as dt
    production_store.clear()
    collection_store.clear()
    production = [
        {"producer":"Detola Ltd.","product_type":"PET Bottles","volume_kg":1000,"zone":"Ikeja","date":dt(2025,8,1)},
        {"producer":"Ayo Bottling","product_type":"PET Bottles","volume_kg":850,"zone":"Yaba","date":dt(2025,8,1)},
        {"producer":"Ada Plastics","product_type":"PET Bottles","volume_kg":740,"zone":"Ajah","date":dt(2025,8,3)},
    ]
    collection = [
        {"collector":"Sanmi Recyclers","source":"Market","volume_kg":150,"zone":"Lekki","date":dt(2025,8,2)},
        {"collector":"Mayowa Green","source":"Community","volume_kg":180,"zone":"Surulere","date":dt(2025,8,2)},
        {"collector":"Yaba Youth","source":"Community","volume_kg":210,"zone":"Yaba","date":dt(2025,8,4)},
    ]
    for p in production:
        production_store.append(ProductionEntry(**p))
    for c in collection:
        collection_store.append(CollectionEntry(**c))
    return {"ok": True, "production": len(production_store), "collection": len(collection_store)}

@app.get("/insights")
def insights(target_rate: float = 0.30):
    s = stats()
    recs = []
    rate = s["recycling_rate"]
    if rate < target_rate:
        recs.append(f"Recovery rate {rate*100:.1f}% is below target {target_rate*100:.0f}%. Incentivize collection in high-production zones.")
    for z in s["by_zone"]:
        p, c = z["produced"], z["collected"]
        if p > 0 and (c/p) < target_rate * 0.75:
            recs.append(f"Zone {z['zone']}: low recovery ({c:.0f}/{p:.0f}). Consider deposit-refund and community drives.")
    if not recs:
        recs.append("Recovery meets target. Maintain programs and monitor for anomalies.")
    return {"insights": recs}
