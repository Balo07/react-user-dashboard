from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_seed_stats_flow():
    r = client.post("/seed")
    assert r.status_code == 200
    r = client.get("/stats")
    assert r.status_code == 200
    data = r.json()
    assert "total_produced" in data
    assert "total_collected" in data
    assert "recycling_rate" in data

def test_add_entries_and_recent():
    client.post("/seed")
    p = {"producer":"TestCo","product_type":"PET Bottles","volume_kg":500,"zone":"Ikeja","date":"2025-08-05"}
    c = {"collector":"TestCollector","source":"Market","volume_kg":100,"zone":"Ikeja","date":"2025-08-06"}
    rp = client.post("/production", json=p)
    rc = client.post("/collection", json=c)
    assert rp.status_code == 200 and rc.status_code == 200
    recent = client.get("/recent").json()
    assert len(recent) > 0
