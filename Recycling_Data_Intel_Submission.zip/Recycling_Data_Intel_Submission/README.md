# Recycling Data Intelligence Platform

Track plastic production (stakeholders) and collection (market, community, environment) to drive policy decisions.

## Features
- React + Tailwind dashboard with stats and table
- FastAPI backend: production, collection, stats, recent, seed, insights
- AI-style insights and anomaly checks
- Docs and CI included

## Quick Start

### Backend
```
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Open http://localhost:8000/docs

### Frontend
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Tests
```
cd backend
pytest -q
```
