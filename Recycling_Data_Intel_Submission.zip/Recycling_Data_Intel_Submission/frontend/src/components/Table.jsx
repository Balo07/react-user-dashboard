import React from "react";

export default function Table({ rows = [] }){
  return (
    <table className="min-w-full text-sm">
      <thead className="bg-slate-50">
        <tr className="text-left text-slate-600">
          <th className="px-4 py-3">Kind</th>
          <th className="px-4 py-3">Entity</th>
          <th className="px-4 py-3">Zone</th>
          <th className="px-4 py-3">Volume (kg)</th>
          <th className="px-4 py-3">Date</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r,i)=> (
          <tr key={i} className="border-t border-slate-100 text-slate-800">
            <td className="px-4 py-2 capitalize">{r.kind}</td>
            <td className="px-4 py-2">{r.entity}</td>
            <td className="px-4 py-2">{r.zone || "-"}</td>
            <td className="px-4 py-2">{r.volume_kg}</td>
            <td className="px-4 py-2">{r.date}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
