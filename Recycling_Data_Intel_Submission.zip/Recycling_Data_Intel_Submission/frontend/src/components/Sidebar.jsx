import React from "react";

export default function Sidebar(){
  const items = ["Dashboard","Producers","Collectors","Reports","Settings"];
  return (
    <aside className="w-64 min-h-screen bg-slate-900 text-slate-50">
      <div className="p-4 text-lg font-semibold">Recycling Intel - Ayo.B</div>
      <nav className="px-2 space-y-1">
        {items.map((label,i)=> (
          <a key={i} href="#" className={`block rounded-md px-3 py-2 text-sm hover:bg-slate-800 ${i===0?'bg-slate-800':''}`}>{label}</a>
        ))}
      </nav>
    </aside>
  );
}
