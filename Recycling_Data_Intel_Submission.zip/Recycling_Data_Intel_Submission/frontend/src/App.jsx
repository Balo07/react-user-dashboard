import React, { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar.jsx";
import StatsCard from "./components/StatsCard.jsx";
import Table from "./components/Table.jsx";

const API = "http://localhost:8000";

export default function App(){
  const [stats, setStats] = useState(null);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const s = await fetch(`${API}/stats`).then(r=>r.json());
      const r = await fetch(`${API}/recent`).then(r=>r.json());
      setStats(s);
      setRows(r);
    } catch(e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  async function seed() {
    await fetch(`${API}/seed`, { method: "POST" });
    await load();
  }

  useEffect(()=>{ load(); }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 space-y-6">
          <header className="flex items-center justify-between">
            <h1 className="text-xl font-semibold">Recycling Data Intelligence - Ayo.B</h1>
            <button onClick={seed} className="px-3 py-1.5 text-sm rounded-md bg-brand-600 text-white hover:bg-brand-700">
              Seed Demo Data
            </button>
          </header>

          {loading && <div className="text-sm text-slate-500">Loading...</div>}

          {!loading && stats && (
            <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <StatsCard label="Total Produced (kg)" value={stats.total_produced} />
              <StatsCard label="Total Collected (kg)" value={stats.total_collected} />
              <StatsCard label="Recycling Rate" value={`${(stats.recycling_rate*100).toFixed(1)}%`} />
              <StatsCard label="Zones" value={stats.by_zone.length} />
            </section>
          )}

          <section className="bg-white rounded-lg border border-slate-200 shadow-sm">
            <div className="p-4 flex items-center justify-between gap-2">
              <h2 className="font-semibold text-slate-800">Recent Entries</h2>
            </div>
            <div className="overflow-x-auto">
              <Table rows={rows} />
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
